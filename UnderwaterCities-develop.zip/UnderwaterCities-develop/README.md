# UnderwaterCities

A text game where you must choose the correct path to win

--------------------------------------------------------------------------------

**Code Organization**

--------------------------------------------------------------------------------


The Program will be placed within the code folder, with the classes 
located in the src folder, and assorted dependencies loose in the code folder.

Nathaniel -> inteliji

Daniel -> eclipse
